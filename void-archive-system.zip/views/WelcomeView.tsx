
import React from 'react';

interface Props {
  onAccess: () => void;
}

const WelcomeView: React.FC<Props> = ({ onAccess }) => {
  return (
    <div className="relative flex flex-col items-center justify-between px-8 pt-32 pb-16 min-h-screen">
      <div className="flex flex-col items-center text-center">
        <div className="mb-10 opacity-60">
          <span className="material-symbols-outlined text-archive-accent text-4xl">
            auto_stories
          </span>
        </div>
        <h1 className="font-header text-archive-text text-5xl font-light uppercase tracking-[0.4em] leading-tight">
          Hello,<br/>void
        </h1>
      </div>

      <div className="flex flex-col items-center text-center max-w-xs space-y-6">
        <div className="space-y-4">
          <p className="text-archive-accent text-sm leading-relaxed tracking-wider animate-pulse">
            [ ACCESSING ARCHIVE... ]
          </p>
          <p className="text-archive-dim text-xs uppercase tracking-[0.2em] leading-loose">
            Where every character finds a voice, and every story finds a home.
          </p>
        </div>
        <div className="h-px w-8 bg-archive-grey"></div>
        <p className="text-archive-dim text-[10px] tracking-[0.3em]">
          RECORD_PROTOCOL_V.4.0
        </p>
      </div>

      <div className="w-full max-w-[280px] space-y-10">
        <div className="flex flex-col items-center">
          <button 
            onClick={onAccess}
            className="group relative flex w-full cursor-pointer items-center justify-center bg-transparent thin-border border-archive-grey h-14 transition-all duration-300 hover:border-archive-accent"
          >
            <span className="text-archive-accent text-sm font-light tracking-[0.5em] uppercase pl-2">
              接入终端
            </span>
          </button>
          <div className="mt-6 flex flex-col items-center">
            <div className="w-1 h-1 bg-archive-accent shadow-[0_0_8px_#00A3FF]"></div>
          </div>
        </div>
        <div className="text-center">
          <button className="text-archive-dim hover:text-archive-text transition-colors text-[10px] tracking-[0.2em] uppercase underline-offset-8">
            初来乍到？点我注册！
          </button>
        </div>
      </div>

      <div className="absolute top-6 left-6 w-4 h-4 border-l border-t border-archive-grey opacity-30"></div>
      <div className="absolute bottom-6 right-6 w-4 h-4 border-r border-b border-archive-grey opacity-30"></div>
    </div>
  );
};

export default WelcomeView;