
import React, { useState, useEffect, useMemo } from 'react';
import { AppView, Character, ArchiveLog, UserProfile, Comment } from './types';
import { MOCK_CHARACTERS, MOCK_LOGS } from './constants';

// Views
import WelcomeView from './views/WelcomeView';
import DashboardView from './views/DashboardView';
import CharacterListView from './views/CharacterListView';
import CharacterDetailView from './views/CharacterDetailView';
import ProfileView from './views/ProfileView';
import CharacterEditorView from './views/CharacterEditorView';
import LogEditorView from './views/LogEditorView';
import LogDetailView from './views/LogDetailView';
import DraftsView from './views/DraftsView';
import SavedArchiveView from './views/SavedArchiveView';
import MyCharactersView from './views/MyCharactersView';
import SettingsView from './views/SettingsView';
import CommentView from './views/CommentView';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.WELCOME);
  const [navigationSource, setNavigationSource] = useState<AppView | null>(null);
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);
  const [selectedLog, setSelectedLog] = useState<ArchiveLog | null>(null);
  const [characters, setCharacters] = useState<Character[]>(MOCK_CHARACTERS);
  const [logs, setLogs] = useState<ArchiveLog[]>(MOCK_LOGS);
  
  const [userProfile, setUserProfile] = useState<UserProfile>({
    name: 'Silver_Mist',
    signature: '在月光的静默中，我们书写命运的剧本...',
    avatarUrl: 'https://picsum.photos/300/300',
    theme: 'dark'
  });

  // Calculate stats for Profile
  const stats = useMemo(() => {
    const publishedLogs = logs.filter(l => l.status !== 'Standby');
    const totalWords = publishedLogs.reduce((acc, log) => {
      const count = parseInt(log.wordCount.replace(/,/g, '')) || 0;
      return acc + count;
    }, 0);
    
    return {
      logsCount: publishedLogs.length,
      wordCount: totalWords >= 1000 ? (totalWords / 1000).toFixed(1) + 'k' : totalWords.toString(),
      charactersCount: characters.filter(c => !c.isDraft).length
    };
  }, [logs, characters]);

  // Apply theme to document
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', userProfile.theme || 'dark');
  }, [userProfile.theme]);

  const navigateTo = (view: AppView, payload?: any) => {
    if (payload?.hasOwnProperty('character')) setSelectedCharacter(payload.character);
    if (payload?.hasOwnProperty('log')) {
      setSelectedLog(payload.log);
    }
    
    if (payload?.hasOwnProperty('from')) {
      setNavigationSource(payload.from);
    } else {
      if (view !== AppView.LOG_EDITOR && view !== AppView.CHARACTER_EDITOR) {
        setNavigationSource(null);
      }
    }

    setCurrentView(view);
    window.scrollTo(0, 0);
  };

  const handleCreateNewCharacter = (fromView?: AppView) => {
    navigateTo(AppView.CHARACTER_EDITOR, { 
      character: {
        id: `char_temp_${Date.now()}`,
        name: '',
        title: '',
        tags: [],
        attributes: { height: '', age: '', alignment: '无', gender: '' },
        ability: '',
        stats: '力量：C\n速度：C\n耐久：C\n射程：C\n精密度：C\n成长性：C',
        trivia: [],
        introduction: '',
        imageUrl: 'https://picsum.photos/800/400?grayscale',
        isDraft: true
      },
      from: fromView
    });
  };

  const handleSaveCharacter = (char: Character, asDraft: boolean = false) => {
    const updatedChar = { ...char, isDraft: asDraft };
    setCharacters(prev => {
      const exists = prev.find(c => c.id === char.id);
      if (exists) {
        return prev.map(c => c.id === char.id ? updatedChar : c);
      } else {
        return [updatedChar, ...prev];
      }
    });

    if (navigationSource === AppView.DRAFTS) {
      navigateTo(AppView.DRAFTS);
    } else if (asDraft) {
      navigateTo(AppView.DRAFTS);
    } else {
      navigateTo(AppView.CHARACTER_LIST);
    }
  };

  const handleDeleteCharacter = (id: string) => {
    setCharacters(prev => prev.filter(c => c.id !== id));
  };

  const handleCreateNewLog = (fromView?: AppView) => {
    navigateTo(AppView.LOG_EDITOR, { 
      log: {
        id: 'new',
        title: '未命名戏录',
        status: 'Ongoing',
        timestamp: new Date().toLocaleDateString(),
        wordCount: '0',
        summary: '开始一段新的记录...',
        imageUrl: 'https://picsum.photos/800/400?grayscale',
        participants: [],
        entries: []
      },
      from: fromView
    });
  };

  const handleSaveLog = (updatedLog: ArchiveLog) => {
    const isNew = updatedLog.id === 'new';
    const finalEntries = updatedLog.entries || [];
    const savedLog: ArchiveLog = { 
      ...updatedLog, 
      id: isNew ? `log_${Date.now()}` : updatedLog.id,
      wordCount: finalEntries.reduce((acc, e) => acc + e.content.length, 0).toLocaleString()
    };

    setLogs(prev => {
      if (isNew) {
        return [savedLog, ...prev];
      } else {
        return prev.map(l => l.id === savedLog.id ? savedLog : l);
      }
    });
    
    setSelectedLog(savedLog);

    if (navigationSource === AppView.DRAFTS) {
      navigateTo(AppView.DRAFTS);
    } else {
      navigateTo(AppView.DASHBOARD);
    }
  };

  const handleDeleteLog = (logId: string) => {
    setLogs(prev => prev.filter(l => l.id !== logId));
  };

  const handleToggleFavorite = (logId: string) => {
    setLogs(prev => prev.map(l => {
      if (l.id === logId) {
        const updated = { ...l, isFavorite: !l.isFavorite };
        if (selectedLog?.id === logId) {
          setSelectedLog(updated);
        }
        return updated;
      }
      return l;
    }));
  };

  const handleAddComment = (logId: string, comment: Comment) => {
    setLogs(prev => prev.map(l => {
      if (l.id === logId) {
        const updated = { ...l, comments: [...(l.comments || []), comment] };
        if (selectedLog?.id === logId) {
          setSelectedLog(updated);
        }
        return updated;
      }
      return l;
    }));
  };

  const handleDeleteComment = (logId: string, commentId: string) => {
    setLogs(prev => prev.map(l => {
      if (l.id === logId) {
        const updated = { ...l, comments: (l.comments || []).filter(c => c.id !== commentId) };
        if (selectedLog?.id === logId) {
          setSelectedLog(updated);
        }
        return updated;
      }
      return l;
    }));
  };

  const renderView = () => {
    switch (currentView) {
      case AppView.WELCOME:
        return <WelcomeView onAccess={() => navigateTo(AppView.DASHBOARD)} />;
      case AppView.DASHBOARD:
        return <DashboardView 
                  logs={logs.filter(l => l.status !== 'Standby')} 
                  characters={characters}
                  onSelectLog={(log) => navigateTo(AppView.LOG_DETAIL, { log })}
                  onContinueLog={(log) => navigateTo(AppView.LOG_EDITOR, { log })}
                  onAddLog={() => handleCreateNewLog()}
                  onToggleFavorite={handleToggleFavorite}
                  onNavigateToCharacters={() => navigateTo(AppView.CHARACTER_LIST)}
                  onNavigateToProfile={() => navigateTo(AppView.PROFILE)}
                />;
      case AppView.CHARACTER_LIST:
        return <CharacterListView 
                  characters={characters.filter(c => !c.isDraft)} 
                  onSelectCharacter={(char) => navigateTo(AppView.CHARACTER_DETAIL, { character: char })}
                  onAddCharacter={() => handleCreateNewCharacter()}
                  onBack={() => navigateTo(AppView.DASHBOARD)}
                  onNavigateToProfile={() => navigateTo(AppView.PROFILE)}
                />;
      case AppView.CHARACTER_DETAIL:
        return <CharacterDetailView 
                  character={selectedCharacter!} 
                  onBack={() => navigateTo(AppView.CHARACTER_LIST)}
                  onEdit={() => navigateTo(AppView.CHARACTER_EDITOR, { character: selectedCharacter })}
                  onStartLog={() => navigateTo(AppView.LOG_EDITOR, { 
                    log: {
                      id: 'new',
                      title: `${selectedCharacter?.name} 的新篇章`,
                      status: 'Ongoing',
                      timestamp: new Date().toLocaleDateString(),
                      wordCount: '0',
                      summary: `关于 ${selectedCharacter?.name} 的新故事。`,
                      imageUrl: selectedCharacter?.imageUrl || '',
                      participants: [selectedCharacter?.name || ''],
                      entries: []
                    }
                  })}
                />;
      case AppView.CHARACTER_EDITOR:
        return <CharacterEditorView 
                  character={selectedCharacter} 
                  onSave={(char) => handleSaveCharacter(char, false)}
                  onSaveDraft={(char) => handleSaveCharacter(char, true)}
                  onCancel={() => {
                    if (navigationSource === AppView.DRAFTS) {
                      navigateTo(AppView.DRAFTS);
                    } else {
                      navigateTo(AppView.CHARACTER_LIST);
                    }
                  }}
                />;
      case AppView.LOG_DETAIL:
        return <LogDetailView 
                  log={selectedLog!} 
                  onBack={() => navigateTo(AppView.DASHBOARD)}
                  onToggleFavorite={() => handleToggleFavorite(selectedLog!.id)}
                  onOpenComments={() => navigateTo(AppView.COMMENTS, { log: selectedLog })}
                />;
      case AppView.COMMENTS:
        return <CommentView 
                  log={selectedLog!}
                  userProfile={userProfile}
                  onBack={() => navigateTo(AppView.LOG_DETAIL, { log: selectedLog })}
                  onAddComment={(comment) => handleAddComment(selectedLog!.id, comment)}
                  onDeleteComment={(commentId) => handleDeleteComment(selectedLog!.id, commentId)}
                />;
      case AppView.LOG_EDITOR:
        return <LogEditorView 
                  log={selectedLog} 
                  availableCharacters={characters.filter(c => !c.isDraft)}
                  onBack={() => {
                    if (navigationSource === AppView.DRAFTS) {
                      navigateTo(AppView.DRAFTS);
                    } else {
                      navigateTo(AppView.DASHBOARD);
                    }
                  }} 
                  onSave={handleSaveLog}
                  onDeleteLog={handleDeleteLog}
                />;
      case AppView.PROFILE:
        return <ProfileView 
                  userProfile={userProfile}
                  logsCount={stats.logsCount}
                  wordCount={stats.wordCount}
                  charactersCount={stats.charactersCount}
                  onBack={() => navigateTo(AppView.DASHBOARD)} 
                  onLogout={() => navigateTo(AppView.WELCOME)}
                  onNavigateToCharacters={() => navigateTo(AppView.CHARACTER_LIST)}
                  onNavigateToDrafts={() => navigateTo(AppView.DRAFTS)}
                  onNavigateToSavedArchive={() => navigateTo(AppView.SAVED_ARCHIVE)}
                  onNavigateToMyCharacters={() => navigateTo(AppView.MY_CHARACTERS)}
                  onNavigateToSettings={() => navigateTo(AppView.SETTINGS)}
                />;
      case AppView.DRAFTS:
        return <DraftsView 
                  logs={logs.filter(l => l.status === 'Ongoing')}
                  characters={characters} 
                  onSelectDraft={(log) => navigateTo(AppView.LOG_EDITOR, { log, from: AppView.DRAFTS })}
                  onSelectCharacterDraft={(char) => navigateTo(AppView.CHARACTER_EDITOR, { character: char, from: AppView.DRAFTS })}
                  onDeleteDraft={handleDeleteLog}
                  onDeleteCharacterDraft={handleDeleteCharacter}
                  onAddLog={() => handleCreateNewLog(AppView.DRAFTS)}
                  onAddCharacter={() => handleCreateNewCharacter(AppView.DRAFTS)}
                  onBack={() => navigateTo(AppView.PROFILE)}
                />;
      case AppView.SAVED_ARCHIVE:
        return <SavedArchiveView 
                  logs={logs.filter(l => l.isFavorite)}
                  onSelectLog={(log) => navigateTo(AppView.LOG_DETAIL, { log })}
                  onBack={() => navigateTo(AppView.PROFILE)}
                />;
      case AppView.MY_CHARACTERS:
        return <MyCharactersView 
                  characters={characters.filter(c => !c.isDraft)}
                  onSelectCharacter={(char) => navigateTo(AppView.CHARACTER_DETAIL, { character: char })}
                  onAddCharacter={() => handleCreateNewCharacter()}
                  onBack={() => navigateTo(AppView.PROFILE)}
                />;
      case AppView.SETTINGS:
        return <SettingsView 
                  profile={userProfile}
                  onSave={(newProfile) => {
                    setUserProfile(newProfile);
                    navigateTo(AppView.PROFILE);
                  }}
                  onBack={() => navigateTo(AppView.PROFILE)}
                />;
      default:
        return <WelcomeView onAccess={() => navigateTo(AppView.DASHBOARD)} />;
    }
  };

  return (
    <div className="relative min-h-screen max-w-md mx-auto bg-archive-black overflow-hidden shadow-2xl">
      <div className="fixed inset-0 noise-bg z-[100] pointer-events-none"></div>
      {renderView()}
    </div>
  );
};

export default App;
